from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from .models import Category, Films
from .forms import FilmsForm
from django.http import HttpResponseRedirect, HttpResponse, HttpResponseNotFound

def index(request):
    films = Films.objects.all()
    return render(request, 'index.html', {'films': films})



def add(request):
    forms = FilmsForm()
    if request.method == 'POST':
        form = FilmsForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/')
    return render(request, 'add.html', {'forma': forms})


def edit(request, id):
    try:
        film = Films.objects.get(id = id)
        film.delete()

        if request.method == 'POST':
            film.name = request.POST.get('name')
            film.category = request.POST.get('category')
            film.rel_date = request.POST.get('rel_date')
            film.actors = request.POST.get('actors')
            film.show_date = request.POST.get('show_date')
            film.save()
            return HttpResponseRedirect('/')
        else:
            genre = Category.objects.all()
            return render(request, 'edit.html', {'genre': genre})
    except Films.DoesNotExist:
        return HttpResponseNotFound('<h2>not found!</h2>')


def delete(request, id):
    try:
        product = Product.objects.get(id=id)
        product.delete()
        return HttpResponseRedirect('/')
    except Product.DoesNotExist:
        return HttpResponseNotFound('<h2>not found!</h2>')


