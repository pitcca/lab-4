from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from appFilimonov import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('add', views.add, name='add'),
    path('edit', views.add, name='edit'),
    path('delete', views.add, name='delete'),
]
